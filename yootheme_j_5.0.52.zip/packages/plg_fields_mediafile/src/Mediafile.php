<?php

namespace Joomla\Plugin\Fields\MediaFile;

use DOMElement;
use Joomla\CMS\Form\Form;
use Joomla\Component\Fields\Administrator\Plugin\FieldsPlugin;

class Mediafile extends FieldsPlugin
{
    public function onCustomFieldsPrepareDom($field, DOMElement $parent, Form $form)
    {
        $fieldNode = parent::onCustomFieldsPrepareDom($field, $parent, $form);

        if ($fieldNode) {
            $noticeNode = $parent->ownerDocument->createElement('field');
            $noticeNode->setAttribute(
                'name',
                sprintf('@deprecation_notice_%s', $field->id ?? $field->name),
            );
            $noticeNode->setAttribute('type', 'note');
            $noticeNode->setAttribute('class', 'alert alert-warning');
            $noticeNode->setAttribute('description', 'PLG_FIELDS_MEDIAFILE_DEPRECATION_NOTICE');

            $parent->insertBefore($noticeNode, $fieldNode);

            $fieldNode->setAttribute('type', 'Media');
            $fieldNode->setAttribute('preview', 'false');
            $fieldNode->setAttribute('types', 'images,audios,videos,documents');
        }

        return $fieldNode;
    }
}
