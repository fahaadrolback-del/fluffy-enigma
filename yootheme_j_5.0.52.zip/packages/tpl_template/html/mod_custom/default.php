<?php

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die;

if (!$module->content) {
    return;
}

$image = $params->get('backgroundimage')
    ? Uri::root(true) . '/' . HTMLHelper::cleanImageURL($params->get('backgroundimage'))->url
    : false;

?>

<div class="uk-margin-remove-last-child custom" <?= $image ? " style=\"background-image:url({$image})\"" : '' ?>><?= $module->content ?></div>
