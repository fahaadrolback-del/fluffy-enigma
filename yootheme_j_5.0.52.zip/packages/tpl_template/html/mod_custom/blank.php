<?php
// Blank module template for Header and Mobile Header Search

defined('_JEXEC') or die;

echo $module->content;
