<?php

namespace YOOtheme;

use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die;

$view = app(View::class);

if (!$params->get('showLast', 1)) {
    array_pop($list);
} elseif ($list) {
    array_last($list)->link = '';
}

foreach ($list as $item) {
    if (!empty($item->link)) {
        $item->link = Route::_($item->link, true, Route::TLS_IGNORE, true);
    }
}

echo $view('~theme/templates/breadcrumbs', [
    'items' => $list,
    'schemaorgId' => Uri::root() . '#/schema/BreadcrumbList/' . (int) $module->id
]);
