<?php

namespace YOOtheme\Builder\Joomla\Fields\Type;

use YOOtheme\Builder\Source;
use function YOOtheme\trans;

/**
 * @phpstan-import-type ObjectConfig from Source
 */
class AudioFieldType
{
    /**
     * @return ObjectConfig
     */
    public static function config(): array
    {
        return [
            'fields' => [
                'file' => [
                    'type' => 'String',
                    'metadata' => [
                        'label' => trans('File'),
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::file',
                    ],
                ],
            ],
        ];
    }

    /**
     * @param array<string, string> $audio
     */
    public static function file($audio): ?string
    {
        return rawurldecode($audio['file'] ?? '') ?: null;
    }
}
