<?php

namespace YOOtheme\Builder\Joomla\Fields\Type;

use Joomla\Uri\Uri;
use YOOtheme\Builder\Source;
use YOOtheme\Path;
use function YOOtheme\trans;

/**
 * @phpstan-import-type ObjectConfig from Source
 */
class DocumentFieldType
{
    /**
     * @return ObjectConfig
     */
    public static function config(): array
    {
        return [
            'fields' => [
                'file' => [
                    'type' => 'File',
                    'metadata' => [
                        'label' => trans('File'),
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::file',
                    ],
                ],
                'linktext' => [
                    'type' => 'String',
                    'metadata' => [
                        'label' => trans('Link Text'),
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::linktext',
                    ],
                ],
            ],
        ];
    }

    /**
     * @param array<string, string> $document
     */
    public static function file($document): ?string
    {
        $file = rawurldecode($document['file'] ?? '');
        $file = !$file || str_starts_with($file, '~') ? $file : Path::join('~', $file);
        return $file ?: null;
    }

    /**
     * @param array<string, string> $document
     */
    public static function linktext($document): ?string
    {
        $linkText = $document['linktext'] ?? '';

        if (!str_contains($linkText, '{filename}')) {
            return $linkText;
        }

        $fileUrl = $document['file'] ?? '';

        if (!$fileUrl) {
            return $linkText;
        }

        $fileUrl = (new Uri($fileUrl))->getPath() ?: $fileUrl;

        return str_replace('{filename}', basename($fileUrl), $linkText);
    }
}
