<?php

namespace YOOtheme\Builder\Joomla\Fields\Type;

use YOOtheme\Builder\Source;
use function YOOtheme\trans;

/**
 * @phpstan-import-type ObjectConfig from Source
 */
class VideoFieldType
{
    /**
     * @return ObjectConfig
     */
    public static function config(): array
    {
        return [
            'fields' => [
                'file' => [
                    'type' => 'String',
                    'metadata' => [
                        'label' => trans('File'),
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::file',
                    ],
                ],
                'poster' => [
                    'type' => 'String',
                    'metadata' => [
                        'label' => trans('Poster'),
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::poster',
                    ],
                ],
            ],
        ];
    }

    /**
     * @param array<string, string> $video
     */
    public static function file($video): ?string
    {
        return rawurldecode($video['file'] ?? '') ?: null;
    }

    /**
     * @param array<string, string> $video
     */
    public static function poster($video): ?string
    {
        return rawurldecode($video['poster'] ?? '') ?: null;
    }
}
