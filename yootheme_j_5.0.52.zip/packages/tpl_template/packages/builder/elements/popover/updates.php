<?php

namespace YOOtheme;

return [
    '4.5.0-beta.0.4' => function ($node) {
        unset($node->props['icon']);
    },

    '4.0.0-beta.9' => function ($node) {
        if (($node->props['panel_link'] ?? '') && ($node->props['css'] ?? '')) {
            $node->props['css'] = str_replace('.el-item', '.el-item > *', $node->props['css']);
        }
    },

    '2.8.0-beta.0.13' => function ($node) {
        foreach (['title_style', 'meta_style', 'content_style'] as $prop) {
            if (in_array($node->props[$prop] ?? '', ['meta', 'lead'])) {
                $node->props[$prop] = "text-{$node->props[$prop]}";
            }
        }
    },

    '2.0.0-beta.5.1' => function ($node) {
        Arr::updateKeys($node->props, [
            'link_type' => function ($value) {
                if ($value === 'content') {
                    return [
                        'title_link' => true,
                        'image_link' => true,
                        'link_text' => '',
                    ];
                } elseif ($value === 'element') {
                    return [
                        'card_link' => true,
                        'link_text' => '',
                    ];
                }
            },
        ]);
    },

    '1.20.0-beta.1.1' => function ($node) {
        Arr::updateKeys($node->props, ['maxwidth_align' => 'block_align']);
    },

    '1.20.0-beta.0.1' => function ($node) {
        /** @var Config $config */
        $config = app(Config::class);

        [$style] = explode(':', $config('~theme.style'));

        if (
            in_array($style, [
                'craft',
                'district',
                'jack-backer',
                'tomsen-brody',
                'vision',
                'florence',
                'max',
                'nioh-studio',
                'sonic',
                'summit',
                'trek',
            ])
        ) {
            if (
                ($node->props['title_style'] ?? '') === 'h1' ||
                (empty($node->props['title_style']) &&
                    ($node->props['title_element'] ?? '') === 'h1')
            ) {
                $node->props['title_style'] = 'heading-small';
            }
        }

        if (in_array($style, ['florence', 'max', 'nioh-studio', 'sonic', 'summit', 'trek'])) {
            if (($node->props['title_style'] ?? '') === 'h2') {
                $node->props['title_style'] =
                    ($node->props['title_element'] ?? '') === 'h1' ? '' : 'h1';
            } elseif (
                empty($node->props['title_style']) &&
                ($node->props['title_element'] ?? '') === 'h2'
            ) {
                $node->props['title_style'] = 'h1';
            }
        }

        if ($style == 'copper-hill') {
            if (($node->props['title_style'] ?? '') === 'h1') {
                $node->props['title_style'] =
                    ($node->props['title_element'] ?? '') === 'h2' ? '' : 'h2';
            } elseif (
                empty($node->props['title_style']) &&
                ($node->props['title_element'] ?? '') === 'h1'
            ) {
                $node->props['title_style'] = 'h2';
            }
        }
    },

    '1.19.0-beta.0.1' => function ($node) {
        if (($node->props['meta_align'] ?? '') === 'top') {
            $node->props['meta_align'] = 'above-title';
        }

        if (($node->props['meta_align'] ?? '') === 'bottom') {
            $node->props['meta_align'] = 'below-title';
        }

        if (($node->props['link_style'] ?? '') === 'card') {
            $node->props['link_type'] = 'element';
            $node->props['link_style'] = 'default';
        }

        Arr::updateKeys($node->props, ['image_card' => 'image_card_padding']);
    },

    '1.18.10.3' => function ($node) {
        if (($node->props['meta_align'] ?? '') === 'top') {
            if (!empty($node->props['meta_margin'])) {
                $node->props['title_margin'] = $node->props['meta_margin'];
            }
            $node->props['meta_margin'] = '';
        }
    },

    '1.18.10.1' => function ($node) {
        Arr::updateKeys($node->props, [
            'image_inline_svg' => 'image_svg_inline',
            'image_animate_svg' => 'image_svg_animate',
        ]);
    },

    '1.18.0' => function ($node) {
        if (!isset($node->props['meta_color']) && ($node->props['meta_style'] ?? '') === 'muted') {
            $node->props['meta_color'] = 'muted';
            $node->props['meta_style'] = '';
        }
    },
];
