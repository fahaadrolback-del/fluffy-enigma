<?php

// Override default settings
$element['link_style'] = $props['link_style'] ?: $element['link_style'];

// Title
$title = $this->el($element['title_element'], [

    'class' => [
        'el-title',
        'uk-{title_style}',
        'uk-card-title {@panel_style} {@!title_style}',
        'uk-heading-{title_decoration}',
        'uk-font-{title_font_family}',
        'uk-text-{title_color} {@!title_color: background}',
        'uk-link-{title_hover_style} {@title_link}', // Set here to style links which already come with dynamic content (WP taxonomy links)
        'uk-margin[-{title_margin}]-top',
        'uk-margin-remove-bottom {@!title_margin_auto}',
        'uk-margin-auto-bottom {@title_margin_auto}',
    ],

]);

$titleInner = $element['title_color'] == 'background' || $element['title_decoration'] == 'line' ? $this->el('span', [

    'class' => [
        'uk-text-background' => $element['title_color'] == 'background',
    ],

]) : null;

// Meta
$meta = $this->el($element['meta_element'], [

    'class' => [
        'el-meta',
        'uk-{meta_style}',
        'uk-text-{meta_color}',
        'uk-margin[-{meta_margin}]-top',
        'uk-margin-remove-bottom {@!meta_margin_auto}' => str_starts_with($element['meta_style'] ?? '', 'h') || $element['meta_element'] != 'div',
        'uk-margin-auto-bottom {@meta_margin_auto}',
    ],

]);

// Content
$content = $this->el('div', [

    'class' => [
        'el-content uk-panel',
        'uk-{content_style}',
        '[uk-text-left{@content_align}]',
        'uk-dropcap {@content_dropcap}',
        'uk-column-{content_column}[@{content_column_breakpoint}]',
        'uk-column-divider {@content_column} {@content_column_divider}',
        'uk-margin[-{content_margin}]-top',
        'uk-margin-remove-bottom {@!content_margin_auto}' => str_starts_with($element['content_style'] ?? '', 'h'),
        'uk-margin-auto-bottom {@content_margin_auto}',
    ],

]);

// Link
$link_container = $this->el('div', [

    'class' => [
        'uk-margin[-{link_margin}]-top {@!link_margin: remove}',
        'uk-width-1-1 {@link_fullwidth} {@panel_expand}',
    ],

]);

// Title Grid
$grid = $this->el('div', [

    'class' => [
        'uk-child-width-expand',
        $element['title_grid_column_gap'] == $element['title_grid_row_gap'] ? 'uk-grid-{title_grid_column_gap}' : '[uk-grid-column-{title_grid_column_gap}] [uk-grid-row-{title_grid_row_gap}]',
        'uk-margin[-{title_margin}]-top {@!title_margin: remove} {@image_align: top}' => !$props['meta'] || $element['meta_align'] != 'above-title',
        'uk-margin[-{meta_margin}]-top {@!meta_margin: remove} {@image_align: top} {@meta_align: above-title}' => $props['meta'],
        'uk-flex-1 {@content_expand}',
    ],

    'uk-grid' => true,
]);

$cell_title = $this->el('div', [

    'class' => [
        'uk-width-{!title_grid_width: expand}[@{title_grid_breakpoint}]',
        'uk-margin-remove-first-child',
        'uk-flex uk-flex-column {@content_expand}',
    ],

]);

$cell_content = $this->el('div', [

    'class' => [
        'uk-width-auto[@{title_grid_breakpoint}] {@title_grid_width: expand}',
        'uk-margin-remove-first-child',
        'uk-flex uk-flex-column {@content_expand}',
    ],

]);

?>

<?php if ($props['title'] != '' && $element['title_align'] == 'left') : ?>
<?= $grid($element) ?>
    <?= $cell_title($element) ?>
<?php endif ?>

        <?php if ($props['meta'] != '' && $element['meta_align'] == 'above-title') : ?>
        <?= $meta($element, $props['meta']) ?>
        <?php endif ?>

        <?php if ($props['title'] != '') : ?>
        <?= $title($element, $titleInner ? $titleInner([], $props['title']) : $props['title']) ?>
        <?php endif ?>

        <?php if ($props['meta'] != '' && $element['meta_align'] == 'below-title') : ?>
        <?= $meta($element, $props['meta']) ?>
        <?php endif ?>

    <?php if ($props['title'] != '' && $element['title_align'] == 'left') : ?>
    <?= $cell_title->end() ?>
    <?= $cell_content($element) ?>
    <?php endif ?>

        <?php if ($element['image_align'] == 'between') : ?>
        <?= $props['image'] ?>
        <?php endif ?>

        <?php if ($props['meta'] != '' && $element['meta_align'] == 'above-content') : ?>
        <?= $meta($element, $props['meta']) ?>
        <?php endif ?>

        <?php if ($props['content'] != '') : ?>
        <?= $content($element, $props['content']) ?>
        <?php endif ?>

        <?php if ($props['meta'] != '' && $element['meta_align'] == 'below-content') : ?>
        <?= $meta($element, $props['meta']) ?>
        <?php endif ?>

        <?php if ($props['link'] && ($props['link_text'] || $element['link_text'])) : ?>
        <?= $link_container($element, $link($element, $props['link_text'] ?: $element['link_text'])) ?>
        <?php endif ?>

<?php if ($props['title'] != '' && $element['title_align'] == 'left') : ?>
    <?= $cell_content->end() ?>
<?= $grid->end() ?>
<?php endif ?>
