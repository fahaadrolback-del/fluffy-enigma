<?php

namespace YOOtheme\Builder\Joomla\Source\Type;

use YOOtheme\Builder\Source;
use function YOOtheme\trans;

/**
 * @phpstan-import-type ObjectConfig from Source
 */
class CategoryQueryType
{
    /**
     * @var list<string>
     */
    protected static array $view = ['com_content.category'];

    /**
     * @return ObjectConfig
     */
    public static function config(): array
    {
        return [
            'fields' => [
                'category' => [
                    'type' => 'Category',
                    'metadata' => [
                        'label' => trans('Category'),
                        'view' => static::$view,
                        'group' => trans('Page'),
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::resolve',
                    ],
                ],
                'childCategoriesSingle' => [
                    'type' => 'Category',
                    'args' => [
                        'offset' => [
                            'type' => 'Int',
                            'defaultValue' => 0,
                        ],
                    ],
                    'metadata' => [
                        'label' => trans('Child Category'),
                        'view' => static::$view,
                        'group' => trans('Page'),
                        'fields' => [
                            'offset' => [
                                'label' => trans('Start'),
                                'description' => trans(
                                    'Set the starting point to specify which category is loaded.',
                                ),
                                'type' => 'number',
                                'modifier' => 1,
                                'attrs' => [
                                    'min' => 1,
                                    'required' => true,
                                ],
                            ],
                        ],
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::resolveSingle',
                    ],
                ],
                'childCategories' => [
                    'type' => [
                        'listOf' => 'Category',
                    ],
                    'args' => [
                        'offset' => [
                            'type' => 'Int',
                            'defaultValue' => 0,
                        ],
                        'limit' => [
                            'type' => 'Int',
                            'defaultValue' => null,
                        ],
                    ],
                    'metadata' => [
                        'label' => trans('Child Categories'),
                        'view' => static::$view,
                        'group' => trans('Page'),
                        'fields' => [
                            '_offset' => [
                                'description' => trans(
                                    'Set the starting point and limit the number of categories.',
                                ),
                                'type' => 'grid',
                                'width' => '1-2',
                                'fields' => [
                                    'offset' => [
                                        'label' => trans('Start'),
                                        'type' => 'number',
                                        'modifier' => 1,
                                        'attrs' => [
                                            'min' => 1,
                                            'required' => true,
                                        ],
                                    ],
                                    'limit' => [
                                        'label' => trans('Quantity'),
                                        'type' => 'limit',
                                        'attrs' => [
                                            'placeholder' => trans('No limit'),
                                            'min' => 0,
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::resolveChildCategories',
                    ],
                ],
            ],
        ];
    }

    /**
     * @param array<string, mixed> $root
     * @return mixed
     */
    public static function resolve($root)
    {
        if (in_array($root['template'] ?? '', static::$view)) {
            return $root['category'];
        }

        return null;
    }

    /**
     * @param array<string, mixed> $root
     * @param array<string, mixed> $args
     * @return mixed
     */
    public static function resolveChildCategories($root, array $args)
    {
        if (in_array($root['template'] ?? '', static::$view)) {
            $children = $root['children'];
            if ($args['offset'] || $args['limit']) {
                $children = array_slice(
                    $children,
                    (int) $args['offset'],
                    (int) $args['limit'] ?: null,
                );
            }
            return $children;
        }

        return null;
    }

    /**
     * @param array<string, mixed> $root
     * @param array<string, mixed> $args
     * @return mixed
     */
    public static function resolveSingle($root, array $args)
    {
        if (in_array($root['template'] ?? '', static::$view)) {
            return $root['children'][$args['offset'] ?? 0] ?? null;
        }

        return null;
    }
}
