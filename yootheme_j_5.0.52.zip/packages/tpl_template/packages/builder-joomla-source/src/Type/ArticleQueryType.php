<?php

namespace YOOtheme\Builder\Joomla\Source\Type;

use Joomla\Uri\Uri;
use YOOtheme\Builder\Joomla\Source\ArticleHelper;
use YOOtheme\Builder\Source;
use function YOOtheme\trans;

/**
 * @phpstan-import-type ObjectConfig from Source
 */
class ArticleQueryType
{
    /**
     * @var list<string>
     */
    protected static array $view = ['com_content.article'];

    /**
     * @return ObjectConfig
     */
    public static function config(): array
    {
        return [
            'fields' => [
                'article' => [
                    'type' => 'Article',
                    'metadata' => [
                        'label' => trans('Article'),
                        'view' => static::$view,
                        'group' => trans('Page'),
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::resolve',
                    ],
                ],
                'prevArticle' => [
                    'type' => 'Article',
                    'metadata' => [
                        'label' => trans('Previous Article'),
                        'view' => static::$view,
                        'group' => trans('Page'),
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::resolvePreviousArticle',
                    ],
                ],
                'nextArticle' => [
                    'type' => 'Article',
                    'metadata' => [
                        'label' => trans('Next Article'),
                        'view' => static::$view,
                        'group' => trans('Page'),
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::resolveNextArticle',
                    ],
                ],
            ],
        ];
    }

    /**
     * @param array<string, mixed> $root
     * @return mixed|void
     */
    public static function resolve($root)
    {
        if (in_array($root['template'] ?? '', static::$view)) {
            return $root['article'] ?? $root['item'];
        }
    }

    /**
     * @param array<string, mixed> $root
     * @return object|null
     */
    public static function resolvePreviousArticle($root)
    {
        return static::resolveAdjacentArticle($root, 'prev');
    }

    /**
     * @param array<string, mixed> $root
     * @return object|null
     */
    public static function resolveNextArticle($root)
    {
        return static::resolveAdjacentArticle($root, 'next');
    }

    /**
     * @param array<string, mixed> $root
     * @return object|null
     */
    protected static function resolveAdjacentArticle($root, string $key)
    {
        $article = static::resolve($root);

        if (!$article) {
            return null;
        }

        ArticleHelper::applyPageNavigation($article);

        return !empty($article->$key) ? static::getArticleFromUrl($article->$key) : null;
    }

    protected static function getArticleFromUrl(string $url): ?object
    {
        $id = (new Uri($url))->getVar('id', '0');

        return $id ? array_first(ArticleHelper::get($id)) : null;
    }
}
