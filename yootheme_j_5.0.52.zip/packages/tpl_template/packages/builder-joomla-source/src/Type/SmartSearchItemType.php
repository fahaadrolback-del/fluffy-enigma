<?php

namespace YOOtheme\Builder\Joomla\Source\Type;

use Joomla\CMS\Categories\Categories;
use Joomla\CMS\Categories\CategoryNode;
use Joomla\CMS\User\User;
use Joomla\Component\Finder\Administrator\Indexer\Result;
use stdClass;
use YOOtheme\Builder\Joomla\Source\UserHelper;
use YOOtheme\Builder\Source;
use YOOtheme\Path;
use YOOtheme\View;
use function YOOtheme\app;
use function YOOtheme\trans;

/**
 * @phpstan-import-type ObjectConfig from Source
 */
class SmartSearchItemType
{
    /**
     * @return ObjectConfig
     */
    public static function config(): array
    {
        return [
            'fields' => [
                'title' => [
                    'type' => 'String',
                    'metadata' => [
                        'label' => trans('Title'),
                        'filters' => ['limit', 'preserve'],
                    ],
                ],

                'description' => [
                    'type' => 'String',
                    'metadata' => [
                        'label' => trans('Content'),
                        'filters' => ['limit', 'preserve'],
                    ],
                ],

                'publish_start_date' => [
                    'type' => 'String',
                    'metadata' => [
                        'label' => trans('Published Date'),
                        'filters' => ['date'],
                    ],
                ],

                'start_date' => [
                    'type' => 'String',
                    'metadata' => [
                        'label' => trans('Created Date'),
                        'filters' => ['date'],
                    ],
                ],

                'metaString' => [
                    'type' => 'String',
                    'args' => [
                        'format' => [
                            'type' => 'String',
                            'defaultValue' => 'list',
                        ],
                        'separator' => [
                            'type' => 'String',
                            'defaultValue' => '|',
                        ],
                        'link_style' => [
                            'type' => 'String',
                            'defaultValue' => '',
                        ],
                        'show_publish_date' => [
                            'type' => 'Boolean',
                            'defaultValue' => true,
                        ],
                        'show_author' => [
                            'type' => 'Boolean',
                            'defaultValue' => true,
                        ],
                        'show_taxonomy' => [
                            'type' => 'String',
                            'defaultValue' => 'category',
                        ],
                        'parent_id' => [
                            'type' => 'String',
                            'defaultValue' => '0',
                        ],
                        'date_format' => [
                            'type' => 'String',
                            'defaultValue' => '',
                        ],
                    ],
                    'metadata' => [
                        'label' => trans('Meta'),
                        'arguments' => [
                            'format' => [
                                'label' => trans('Format'),
                                'description' => trans(
                                    'Display the meta text in a sentence or a horizontal list.',
                                ),
                                'type' => 'select',
                                'options' => [
                                    trans('List') => 'list',
                                    trans('Sentence') => 'sentence',
                                ],
                            ],
                            'separator' => [
                                'label' => trans('Separator'),
                                'description' => trans('Set the separator between fields.'),
                                'enable' => 'arguments.format === "list"',
                            ],
                            'link_style' => [
                                'label' => trans('Link Style'),
                                'description' => trans('Set the link style.'),
                                'type' => 'select',
                                'options' => [
                                    'Default' => '',
                                    'Muted' => 'link-muted',
                                    'Text' => 'link-text',
                                    'Heading' => 'link-heading',
                                    'Reset' => 'link-reset',
                                ],
                            ],
                            'show_publish_date' => [
                                'label' => trans('Display'),
                                'description' => trans('Show or hide fields in the meta text.'),
                                'type' => 'checkbox',
                                'text' => trans('Show date'),
                            ],
                            'show_author' => [
                                'type' => 'checkbox',
                                'text' => trans('Show author'),
                            ],
                            'show_taxonomy' => [
                                'type' => 'select',
                                'options' => [
                                    trans('Hide Term List') => '',
                                    trans('Show Category') => 'category',
                                    trans('Show Tags') => 'tag',
                                ],
                            ],
                            'parent_id' => [
                                'label' => trans('Parent Tag'),
                                'description' => trans(
                                    'Tags are only loaded from the selected parent tag.',
                                ),
                                'type' => 'select',
                                'show' => 'arguments.show_taxonomy === "tag"',
                                'options' => [
                                    ['value' => '0', 'text' => trans('Root')],
                                    ['evaluate' => 'yootheme.builder.tags'],
                                ],
                            ],
                            'date_format' => [
                                'label' => trans('Date Format'),
                                'description' => trans(
                                    'Select a predefined date format or enter a custom format.',
                                ),
                                'type' => 'data-list',
                                'options' => [
                                    'Aug 6, 1999 (M j, Y)' => 'M j, Y',
                                    'August 06, 1999 (F d, Y)' => 'F d, Y',
                                    '08/06/1999 (m/d/Y)' => 'm/d/Y',
                                    '08.06.1999 (m.d.Y)' => 'm.d.Y',
                                    '6 Aug, 1999 (j M, Y)' => 'j M, Y',
                                    'Tuesday, Aug 06 (l, M d)' => 'l, M d',
                                ],
                                'enable' => 'arguments.show_publish_date',
                                'attrs' => [
                                    'placeholder' => 'Default',
                                ],
                            ],
                        ],
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::metaString',
                    ],
                ],

                'category' => [
                    'type' => 'Category',
                    'metadata' => [
                        'label' => trans('Category'),
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::category',
                    ],
                ],

                'images' => [
                    'type' => 'ArticleImages',
                    'metadata' => [
                        'label' => '',
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::images',
                    ],
                ],

                'route' => [
                    'type' => 'String',
                    'metadata' => [
                        'label' => trans('Link'),
                    ],
                ],

                'author' => [
                    'type' => 'User',
                    'metadata' => [
                        'label' => trans('Author'),
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::author',
                    ],
                ],
            ],

            'metadata' => [
                'type' => true,
            ],
        ];
    }

    /**
     * @param Result $item
     * @param array<string, mixed> $args
     */
    public static function metaString($item, array $args): string
    {
        $props = [
            'id',
            'author',
            'created_by',
            'created_by_alias',
            'contact_link',
            'catid',
            'category' => 'category_title',
        ];

        $article = new stdClass();
        foreach ($props as $field => $prop) {
            $article->$prop = $item->getElement(is_numeric($field) ? $prop : $field);
        }

        $article->publish_up = $item->publish_start_date;
        $tags = $args['show_taxonomy'] === 'tag' ? ArticleType::tags($article, $args) : null;

        return app(View::class)->render(Path::join(__DIR__, '../../templates/meta'), [
            'article' => $article,
            'tags' => $tags,
            'args' => $args,
        ]);
    }

    /**
     * @param Result $item
     *
     * @return array<string, mixed>
     */
    public static function images($item)
    {
        $images = json_decode($item->getElement('images') ?? '');

        // Fallback for plugins not storing images as json representation (like HikaShop)
        if (!$images && $item->getElement('imageUrl')) {
            $images = (object) [
                'image_intro' => $item->getElement('imageUrl'),
                'image_intro_alt' => $item->getElement('imageAlt'),
            ];
        }

        return $images;
    }

    /**
     * @param Result $item
     */
    public static function category($item): ?CategoryNode
    {
        if ($item->getElement('context') === 'com_content.article') {
            $id = $item->getElement('catid');
            return $id && $id !== 'root'
                ? Categories::getInstance('content', ['countItems' => true])->get($id)
                : null;
        }

        return null;
    }

    /**
     * @param Result $item
     */
    public static function author($item): User
    {
        $user = UserHelper::get((int) $item->getElement('created_by'));

        if ($item->getElement('created_by_alias')) {
            $user = clone $user;
            $user->name = $item->getElement('created_by_alias');
        }

        return $user;
    }
}
