<?php

namespace YOOtheme\Builder\Joomla\Source\Type;

use Joomla\CMS\Categories\Categories;
use Joomla\Component\Finder\Administrator\Indexer\Result;
use YOOtheme\Builder\Source;
use function YOOtheme\trans;

/**
 * @phpstan-import-type ObjectConfig from Source
 */
class SmartSearchItemsQueryType
{
    /**
     * @var list<string>
     */
    protected static array $view = ['com_finder.search', '_search'];

    /**
     * @return ObjectConfig
     */
    public static function config(): array
    {
        return [
            'fields' => [
                'smartSearchItem' => [
                    'type' => 'SmartSearchItem',
                    'args' => [
                        'catid' => [
                            'type' => [
                                'listOf' => 'String',
                            ],
                            'defaultValue' => [],
                        ],
                        'offset' => [
                            'type' => 'Int',
                            'defaultValue' => 0,
                        ],
                    ],
                    'metadata' => [
                        'label' => trans('Item'),
                        'view' => static::$view,
                        'group' => trans('Page'),
                        'fields' => [
                            'catid' => [
                                'label' => trans('Filter by Root Categories'),
                                'description' => trans(
                                    'Filter items visually by the selected root categories.',
                                ),
                                'type' => 'select',
                                'options' => [['evaluate' => 'yootheme.builder.root_categories']],
                                'attrs' => [
                                    'multiple' => true,
                                    'class' => 'uk-height-small',
                                ],
                            ],
                            'offset' => [
                                'label' => trans('Start'),
                                'type' => 'number',
                                'modifier' => 1,
                                'attrs' => [
                                    'min' => 1,
                                    'required' => true,
                                ],
                            ],
                        ],
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::resolveSingle',
                    ],
                ],
                'smartSearchItems' => [
                    'type' => [
                        'listOf' => 'SmartSearchItem',
                    ],
                    'args' => [
                        'catid' => [
                            'type' => [
                                'listOf' => 'String',
                            ],
                            'defaultValue' => [],
                        ],
                        'offset' => [
                            'type' => 'Int',
                            'defaultValue' => 0,
                        ],
                        'limit' => [
                            'type' => 'Int',
                            'defaultValue' => null,
                        ],
                    ],
                    'metadata' => [
                        'label' => trans('Items'),
                        'view' => static::$view,
                        'group' => trans('Page'),
                        'fields' => [
                            'catid' => [
                                'label' => trans('Filter by Root Categories'),
                                'description' => trans(
                                    'Filter items visually by the selected root categories.',
                                ),
                                'type' => 'select',
                                'options' => [['evaluate' => 'yootheme.builder.root_categories']],
                                'attrs' => [
                                    'multiple' => true,
                                    'class' => 'uk-height-small',
                                ],
                            ],
                            '_offset' => [
                                'description' => trans(
                                    'Set the starting point and limit the number of items.',
                                ),
                                'type' => 'grid',
                                'width' => '1-2',
                                'fields' => [
                                    'offset' => [
                                        'label' => trans('Start'),
                                        'type' => 'number',
                                        'modifier' => 1,
                                        'attrs' => [
                                            'min' => 1,
                                            'required' => true,
                                        ],
                                    ],
                                    'limit' => [
                                        'label' => trans('Quantity'),
                                        'type' => 'limit',
                                        'attrs' => [
                                            'placeholder' => trans('No limit'),
                                            'min' => 0,
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ],
                    'extensions' => [
                        'call' => __CLASS__ . '::resolve',
                    ],
                ],
            ],
        ];
    }

    /**
     * @param array<string, mixed> $root
     * @param array<string, mixed> $args
     * @return ?list<Result>
     */
    public static function resolve(array $root, array $args): ?array
    {
        if (in_array($root['template'] ?? '', static::$view)) {
            $items = $root['items'] ?? [];

            if ($args['catid']) {
                $model = Categories::getInstance('content', ['countItems' => true]);
                $rootCategories = array_map(fn($catId) => $model->get($catId), $args['catid']);

                if (!$rootCategories) {
                    return [];
                }

                $items = array_filter($items, function ($item) use ($rootCategories, $model) {
                    $id = $item->getElement('catid');

                    if (!$id || $item->getElement('context') !== 'com_content.article') {
                        return false;
                    }

                    $category = $model->get($id);

                    if (!$category) {
                        return false;
                    }

                    foreach ($rootCategories as $rootCategory) {
                        if (array_key_exists($rootCategory->id, $category->getPath())) {
                            return true;
                        }
                    }

                    return false;
                });
            }

            if ($args['offset'] || $args['limit']) {
                $items = array_slice($items, (int) $args['offset'], (int) $args['limit'] ?: null);
            }

            return $items;
        }

        return null;
    }

    /**
     * @param array<string, mixed> $root
     * @param array<string, mixed> $args
     * @return ?Result
     */
    public static function resolveSingle(array $root, array $args)
    {
        return static::resolve($root, $args + ['limit' => 1])[0] ?? null;
    }
}
