<?php

return [
    'sections' => [
        'builder-pages' => [
            'title' => 'Pages',
            'heading' => false,
            'priority' => 19,
        ],
    ],
    'panels' => [
        'builder' => [
            'help' => [
                'Builder' => [
                    [
                        'title' => 'Using the Page Builder',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=gPGmv-O1f-I&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:27',
                        'documentation' => 'docs/joomla/page-builder#page-builder',
                        'support' => 'support/search?tags=125&q=builder',
                    ],
                    [
                        'title' => 'Understanding the Layout Structure',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=ahP4rEXBnIM&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:57',
                        'documentation' =>
                            'docs/joomla/page-builder#layout-structure',
                        'support' => 'support/search?tags=125&q=layout%20structure',
                    ],
                    [
                        'title' => 'Managing Sections, Rows and Elements',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=WBju-Frb0Vg&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:04',
                        'documentation' => 'docs/joomla/page-builder#actions',
                        'support' => 'support/search?tags=125&q=builder%20action',
                    ],
                    [
                        'title' => 'Using the Element Finder',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=GisyKeSWtsU&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:43',
                        'documentation' =>
                            'docs/joomla/page-builder#element-finder',
                        'support' => 'support/search?tags=125&q=builder%20element%20finder',
                    ],
                    [
                        'title' => 'Ordering Sections, Rows and Elements',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=oWBCd3QBPrU&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:23',
                        'documentation' => 'docs/joomla/page-builder#ordering',
                        'support' => 'support/search?tags=125&q=builder%20ordering',
                    ],
                    [
                        'title' => 'Understanding Status Icons',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=cWPuhs4KrtQ&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '3:22',
                        'documentation' => 'docs/joomla/page-builder#status',
                        'support' => 'support/search?tags=125&q=builder%20status%20icon',
                    ],
                    [
                        'title' => 'Working with Multiple Authors',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=vv3IWfviGzc&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:38',
                        'documentation' =>
                            'docs/joomla/page-builder#multi-author-workflow',
                        'support' => 'support/search?tags=125&q=overwriting%20layout',
                    ],
                    [
                        'title' => 'Collapsing Layouts',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=UT6PODf7p3o&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:44',
                        'documentation' => 'docs/joomla/collapsing-layouts',
                        'support' => 'support/search?tags=125&q=collapsing',
                    ],
                    [
                        'title' => 'Learning Layout Techniques',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=z4kw04hhJdo&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:09',
                        'documentation' =>
                            'docs/joomla/element-library#layout-techniques',
                        'support' => 'support/search?tags=125&q=layout%20techniques',
                    ],
                    [
                        'title' => 'Creating Parallax Effects',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=PKVnGZjd0dE&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU',
                        'duration' => '9:59',
                        'documentation' => 'docs/joomla/elements#parallax-settings',
                        'support' => 'support/search?tags=125&q=parallax',
                    ],
                    [
                        'title' => 'Creating Sticky Parallax Effects',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=_fykqti6DYc&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU',
                        'duration' => '19:00',
                        'documentation' =>
                            'docs/joomla/elements#sticky-parallax-effects',
                        'support' => 'support/search?tags=125&q=sticky%20parallax',
                    ],
                ],
                'Images and Links' => [
                    [
                        'title' => 'Using Images',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=NHpFpn4UiUM&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '4:37',
                        'documentation' => 'docs/joomla/files-and-images#images',
                        'support' => 'support/search?tags=125&q=image%20field',
                    ],
                    [
                        'title' => 'Using Links',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=EUNGRsyT1ak&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:40',
                        'documentation' => 'docs/joomla/files-and-images#links',
                        'support' => 'support/search?tags=125&q=link%20field',
                    ],
                    [
                        'title' => 'Using the Media Manager',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=2Sgp4BBMTc8&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:32',
                        'documentation' =>
                            'docs/joomla/files-and-images#media-manager',
                        'support' => 'support/search?tags=125&q=media%20manager',
                    ],
                    [
                        'title' => 'Using the Unsplash Library',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=6piYezAI4dU&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:50',
                        'documentation' =>
                            'docs/joomla/files-and-images#unsplash-and-pexels-libraries',
                        'support' => 'support/search?tags=125&q=unsplash',
                    ],
                ],
                'Layout Library' => [
                    [
                        'title' => 'Using Pro Layouts',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=OvTVcRBW99A&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:26',
                        'documentation' => 'docs/joomla/layout-library#pro-layouts',
                        'support' => 'support/search?tags=125&q=pro%20layouts',
                    ],
                    [
                        'title' => 'Using My Layouts',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=qKN8RME_q60&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:27',
                        'documentation' => 'docs/joomla/layout-library#my-layouts',
                        'support' => 'support/search?tags=125&q=my%20layouts',
                    ],
                    [
                        'title' => 'Loading Layouts',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=r7wJq7E2jCU&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:30',
                        'documentation' =>
                            'docs/joomla/layout-library#loading-layouts',
                        'support' => 'support/search?tags=125&q=loading%20layout',
                    ],
                ],
                'Element Library' => [
                    [
                        'title' => 'Using Elements',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=vj0Eg-hOvoM&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:45',
                        'documentation' => 'docs/joomla/element-library#elements',
                        'support' => 'support/search?tags=125&q=elements',
                    ],
                    [
                        'title' => 'Using Pro Presets',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=wRTD3Y0bvAM&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:01',
                        'documentation' =>
                            'docs/joomla/element-library#pro-presets',
                        'support' => 'support/search?tags=125&q=pro%20presets',
                    ],
                    [
                        'title' => 'Using My Presets',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=m3v75Sb6ruQ&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:18',
                        'documentation' => 'docs/joomla/element-library#my-presets',
                        'support' => 'support/search?tags=125&q=my%20presets',
                    ],
                    [
                        'title' => 'The Alert Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=yGaSNRv6FIg&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:18',
                        'documentation' =>
                            'docs/joomla/basic-elements#alert-element',
                        'support' => 'support/search?tags=125&q=alert%20element',
                    ],
                    [
                        'title' => 'The Code Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=82UaWdmY-d8&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:35',
                        'documentation' =>
                            'docs/joomla/basic-elements#code-element',
                        'support' => 'support/search?tags=125&q=code%20element',
                    ],
                    [
                        'title' => 'The Countdown Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=TyHQjc6hhb8&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:58',
                        'documentation' =>
                            'docs/joomla/basic-elements#countdown-element',
                        'support' => 'support/search?tags=125&q=countdown%20element',
                    ],
                    [
                        'title' => 'The Divider Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=iWNJ4ljupws&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:39',
                        'documentation' =>
                            'docs/joomla/basic-elements#divider-element',
                        'support' => 'support/search?tags=125&q=divider%20element',
                    ],
                    [
                        'title' => 'The Headline Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=vEcEB0I433o&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:18',
                        'documentation' =>
                            'docs/joomla/basic-elements#headline-element',
                        'support' => 'support/search?tags=125&q=headline%20element',
                    ],
                    [
                        'title' => 'The Icon Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=SXO8OTCK8so&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:01',
                        'documentation' =>
                            'docs/joomla/basic-elements#icon-element',
                        'support' => 'support/search?tags=125&q=icon%20element',
                    ],
                    [
                        'title' => 'The Image Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=_mcjMQPN2tQ&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:37',
                        'documentation' =>
                            'docs/joomla/basic-elements#image-element',
                        'support' => 'support/search?tags=125&q=image%20element',
                    ],
                    [
                        'title' => 'The Newsletter Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=FUPzn8pZAtM&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:20',
                        'documentation' =>
                            'docs/joomla/basic-elements#newsletter-element',
                        'support' => 'support/search?tags=125&q=newsletter%20element',
                    ],
                    [
                        'title' => 'The Overlay Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=CaskgXO23yw&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '5:41',
                        'documentation' =>
                            'docs/joomla/basic-elements#overlay-element',
                        'support' => 'support/search?tags=125&q=overlay%20element',
                    ],
                    [
                        'title' => 'The Panel Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=LrTd3WpeCac&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '3:35',
                        'documentation' =>
                            'docs/joomla/basic-elements#panel-element',
                        'support' => 'support/search?tags=125&q=panel%20element',
                    ],
                    [
                        'title' => 'The Quotation Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=qTIZHbYQje8&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:52',
                        'documentation' =>
                            'docs/joomla/basic-elements#quotation-element',
                        'support' => 'support/search?tags=125&q=quotation%20element',
                    ],
                    [
                        'title' => 'The Sublayout Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=BXCv59Wp9Z4&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:53',
                        'documentation' =>
                            'docs/joomla/basic-elements#sublayout-element',
                        'support' => 'support/search?tags=125&q=sublayout%20element',
                    ],
                    [
                        'title' => 'The Text Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=IkJgm2c4w5E&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:17',
                        'documentation' =>
                            'docs/joomla/basic-elements#text-element',
                        'support' => 'support/search?tags=125&q=text%20element',
                    ],
                    [
                        'title' => 'The Totop Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=3sQUAwbasI4&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:33',
                        'documentation' =>
                            'docs/joomla/basic-elements#totop-element',
                        'support' => 'support/search?tags=125&q=totop%20element',
                    ],
                    [
                        'title' => 'The Video Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=GhnVRXG7les&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:30',
                        'documentation' =>
                            'docs/joomla/basic-elements#video-element',
                        'support' => 'support/search?tags=125&q=video%20element',
                    ],
                    [
                        'title' => 'The Accordion Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=sbqNaJVA49g&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:03',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#accordion-element',
                        'support' => 'support/search?tags=125&q=accordion%20element',
                    ],
                    [
                        'title' => 'The Button Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=5f0GyiDTXdM&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:01',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#button-element',
                        'support' => 'support/search?tags=125&q=button%20element',
                    ],
                    [
                        'title' => 'The Description List Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=1QdPBTcgOTc&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:34',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#description-list-element',
                        'support' => 'support/search?tags=125&q=description-list%20element',
                    ],
                    [
                        'title' => 'The Gallery Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=QrY8WGLIk5Y&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '5:15',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#gallery-element',
                        'support' => 'support/search?tags=125&q=gallery%20element',
                    ],
                    [
                        'title' => 'The Grid Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=5viHNXg8TT8&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '5:10',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#grid-element',
                        'support' => 'support/search?tags=125&q=grid%20element',
                    ],
                    [
                        'title' => 'The List Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=2EdPTQyAj4U&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:26',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#list-element',
                        'support' => 'support/search?tags=125&q=list%20element',
                    ],
                    [
                        'title' => 'The Map Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=ihAyS7Ln9RA&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '5:00',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#map-element',
                        'support' => 'support/search?tags=125&q=map%20element',
                    ],
                    [
                        'title' => 'The Nav Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=b7ZsXD-Ki_U&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:32',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#nav-element',
                        'support' => 'support/search?tags=125&q=nav%20element',
                    ],
                    [
                        'title' => 'The Overlay Slider Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=svfBwp0z7ww&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '4:16',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#overlay-slider-element',
                        'support' => 'support/search?tags=125&q=overlay-slider%20element',
                    ],
                    [
                        'title' => 'The Panel Slider Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=B5bFBrK_nMY&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '4:24',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#panel-slider-element',
                        'support' => 'support/search?tags=125&q=panel-slider%20element',
                    ],
                    [
                        'title' => 'The Popover Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=3q2uvJhqEcs&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '3:19',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#popover-element',
                        'support' => 'support/search?tags=125&q=popover%20element',
                    ],
                    [
                        'title' => 'The Slideshow Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=jEDBLkGfIjU&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '6:20',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#slideshow-element',
                        'support' => 'support/search?tags=125&q=slideshow%20element',
                    ],
                    [
                        'title' => 'The Social Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=0U5rHTknT7A&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:32',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#social-element',
                        'support' => 'support/search?tags=125&q=social%20element',
                    ],
                    [
                        'title' => 'The Subnav Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=llyT8HFaXhM&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:33',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#subnav-element',
                        'support' => 'support/search?tags=125&q=subnav%20element',
                    ],
                    [
                        'title' => 'The Switcher Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=fqtWROEKM_o&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '3:58',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#switcher-element',
                        'support' => 'support/search?tags=125&q=switcher%20element',
                    ],
                    [
                        'title' => 'The Table Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=0KGSGKEItPo&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '3:01',
                        'documentation' =>
                            'docs/joomla/multiple-items-elements#table-element',
                        'support' => 'support/search?tags=125&q=table%20element',
                    ],
                    [
                        'title' => 'The Breadcrumbs Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=EBaGuYvm14Q&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:48',
                        'documentation' =>
                            'docs/joomla/system-elements#breadcrumbs-element',
                        'support' => 'support/search?tags=125&q=breadcrumbs%20element',
                    ],
                    [
                        'title' => 'The Module Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=kIwXpttCD8g&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:48',
                        'documentation' =>
                            'docs/joomla/system-elements#module-element',
                        'support' => 'support/search?tags=125&q=module%20element',
                    ],
                    [
                        'title' => 'The Position Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=_LUvr_31n44&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:40',
                        'documentation' =>
                            'docs/joomla/system-elements#position-element',
                        'support' => 'support/search?tags=125&q=position%20element',
                    ],
                    [
                        'title' => 'The Search Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=1BqIOOabndQ&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:46',
                        'documentation' =>
                            'docs/joomla/system-elements#search-element',
                        'support' => 'support/search?tags=125&q=search%20element',
                    ],
                    [
                        'title' => 'The Pagination Element',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=pehfrOcnVLA&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:37',
                        'documentation' =>
                            'docs/joomla/system-elements#pagination-element',
                        'support' => 'support/search?tags=125&q=pagination%20element',
                    ],
                ],
                'Sections' => [
                    [
                        'title' => 'Section Style',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=QDPcpg6p61U&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:53',
                        'documentation' => 'docs/joomla/sections#background',
                        'support' => 'support/search?tags=125&q=section%20style',
                    ],
                    [
                        'title' => 'Section Image and Video',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=w_b7cyPxkvE&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '3:16',
                        'documentation' => 'docs/joomla/sections#image-and-video',
                        'support' => 'support/search?tags=125&q=section%20image',
                    ],
                    [
                        'title' => 'Section Width',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=845DEeI453c&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:33',
                        'documentation' => 'docs/joomla/sections#width',
                        'support' => 'support/search?tags=125&q=section%20width',
                    ],
                    [
                        'title' => 'Section Height',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=ebsJftwWOH4&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:19',
                        'documentation' => 'docs/joomla/sections#height',
                        'support' => 'support/search?tags=125&q=section%20height',
                    ],
                    [
                        'title' => 'Section Padding',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=p3Vy1yiFL9w&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:50',
                        'documentation' => 'docs/joomla/sections#padding',
                        'support' => 'support/search?tags=125&q=section%20padding',
                    ],
                    [
                        'title' => 'Sticky Effect',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=GlOi6Xb56_E&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:48',
                        'documentation' => 'docs/joomla/sections#sticky-effect',
                        'support' => 'support/search?tags=125&q=section%20sticky',
                    ],
                    [
                        'title' => 'Transparent Header',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=fhDFf7YBPdsw&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:53',
                        'documentation' =>
                            'docs/joomla/sections#transparent-header',
                        'support' => 'support/search?tags=125&q=transparent%20header',
                    ],
                    [
                        'title' => 'Section Animation',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=d4RgsgId7Og&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:34',
                        'documentation' => 'docs/joomla/sections#animation',
                        'support' => 'support/search?tags=125&q=section%20animation',
                    ],
                    [
                        'title' => 'Section Title',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=RRN1lJ2Lx14w&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:01',
                        'documentation' => 'docs/joomla/sections#title',
                        'support' => 'support/search?tags=125&q=section%20title',
                    ],
                ],
                'Dynamic Content' => [
                    [
                        'title' => 'Using Content Sources',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=snuMovT0gj8&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:43',
                        'documentation' =>
                            'docs/joomla/dynamic-content#content-sources',
                        'support' => 'support/search?tags=125&q=source',
                    ],
                    [
                        'title' => 'Using Page Sources',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=OPc6CPFhHh8&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:14',
                        'documentation' =>
                            'docs/joomla/dynamic-content#page-sources',
                        'support' => 'support/search?tags=125&q=page%20source',
                    ],
                    [
                        'title' => 'Using Custom Sources',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=bHfKP1rDFyc&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '5:46',
                        'documentation' =>
                            'docs/joomla/dynamic-content#custom-sources',
                        'support' => 'support/search?tags=125&q=custom%20source',
                    ],
                    [
                        'title' => 'Using External Sources',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=bCgewm7_PUU&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:16',
                        'documentation' =>
                            'docs/joomla/dynamic-content#external-sources',
                        'support' => 'support/search?tags=125&q=external%20source',
                    ],
                    [
                        'title' => 'Using Site Sources',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=_43JH-gvs0s&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:01',
                        'documentation' =>
                            'docs/joomla/dynamic-content#site-source',
                        'support' => 'support/search?tags=125&q=site%20source',
                    ],
                    [
                        'title' => 'Using Parent Sources',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=AMeWesuA0H4&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '3:54',
                        'documentation' =>
                            'docs/joomla/dynamic-content#parent-source',
                        'support' => 'support/search?tags=125&q=parent%20source',
                    ],
                    [
                        'title' => 'Using Dynamic Multiplication',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=O-kuq1l8uhk&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '6:49',
                        'documentation' =>
                            'docs/joomla/dynamic-content#multiplication',
                        'support' => 'support/search?tags=125&q=multiplication',
                    ],
                    [
                        'title' => 'Setting the Source Order and Direction',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=Jk7MCXm7uQI&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:02',
                        'documentation' =>
                            'docs/joomla/dynamic-content#order-and-direction',
                        'support' => 'support/search?tags=125&q=source%20order',
                    ],
                    [
                        'title' => 'Using Related Sources',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=ziozc_tfqyg&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '7:44',
                        'documentation' =>
                            'docs/joomla/dynamic-content#related-sources',
                        'support' => 'support/search?tags=125&q=related%20source',
                    ],
                    [
                        'title' => 'Mapping Fields',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=I9HnYh8GruY&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:22',
                        'documentation' =>
                            'docs/joomla/dynamic-content#field-mapping',
                        'support' => 'support/search?tags=125&q=field',
                    ],
                    [
                        'title' => 'Using Content Fields',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=rhR3hkQ0LL0&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '2:09',
                        'documentation' =>
                            'docs/joomla/dynamic-content#content-fields',
                        'support' => 'support/search?tags=125&q=field',
                    ],
                    [
                        'title' => 'Using Custom Fields',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=E2QsGRHWAnc&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:32',
                        'documentation' =>
                            'docs/joomla/dynamic-content#custom-fields',
                        'support' => 'support/search?tags=125&q=custom%20fields',
                    ],
                    [
                        'title' => 'Using Display Conditions',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=_ydI40op2fA&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:23',
                        'documentation' =>
                            'docs/joomla/dynamic-content#display-conditions',
                        'support' => 'support/search?tags=125&q=display%20conditions',
                    ],
                ],
                'Dynamic Content Field Options' => [
                    [
                        'title' => 'Using the Before and After Field Options',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=O2GIOZGim5k&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:40',
                        'documentation' =>
                            'docs/joomla/dynamic-content#before-and-after',
                        'support' => 'support/search?tags=125&q=field%20Before%20After',
                    ],
                    [
                        'title' => 'Using the Search and Replace Field Options',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=_SzEJ8596m0&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '1:25',
                        'documentation' =>
                            'docs/joomla/dynamic-content#search-and-replace',
                        'support' => 'support/search?tags=125&q=field%20Search%20Replace',
                    ],
                    [
                        'title' => 'Using the Content Length Field Option',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=sKiqXDhKPp4&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:23',
                        'documentation' =>
                            'docs/joomla/dynamic-content#content-length',
                        'support' => 'support/search?tags=125&q=field%20length',
                    ],
                    [
                        'title' => 'Using the Date Format Field Option',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=ChJ6WxkOEtI&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:31',
                        'documentation' =>
                            'docs/joomla/dynamic-content#date-format',
                        'support' => 'support/search?tags=125&q=field%20date',
                    ],
                    [
                        'title' => 'Using the Teaser Field Options',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=MM6a8GEf6J8&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:25',
                        'documentation' =>
                            'docs/joomla/dynamic-content#teaser-field',
                        'support' => 'support/search?tags=125&q=field%20teaser',
                    ],
                    [
                        'title' => 'Using the Meta Field Options',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=43das8dQiIk&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:58',
                        'documentation' => 'docs/joomla/dynamic-content#meta-field',
                        'support' => 'support/search?tags=125&q=field%20meta',
                    ],
                    [
                        'title' => 'Using the Tags Field Options',
                        'src' =>
                            'https://www.youtube-nocookie.com/watch?v=IrUqG2AfkfI&amp;list=PLrqT0WH0HPdPfykSwhMt6Jl2_RgJ6ixU-',
                        'duration' => '0:32',
                        'documentation' => 'docs/joomla/dynamic-content#tags-field',
                        'support' => 'support/search?tags=125&q=field%20tags',
                    ],
                ],
            ],
        ],
    ],
];
